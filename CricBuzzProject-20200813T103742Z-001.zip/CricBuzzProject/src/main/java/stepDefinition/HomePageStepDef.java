package stepDefinition;

import org.openqa.selenium.By;

import basement.CricBuzzBasement;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;
import pages.HomePage;
import pages.LiveScorePage;
import pages.SchedulePage;
import pages.SeriesPage;

public class HomePageStepDef extends CricBuzzBasement {

	HomePage homepageobj;
	SchedulePage schedulepageobj;
	SeriesPage seriespageobj;
	LiveScorePage livescorepageobj;

	@Given("^user open the brower and enter the cricbuzz url$")
	public void user_open_the_brower_and_enter_the_cricbuzz_url() {

		startup();
		homepageobj = new HomePage();

	}

	@When("^user check the home page title$")
	public void user_check_the_home_page_title() {

		
		  String title = driver.getTitle(); Assert.
		  assertEquals("Cricket Score, Schedule, Latest News, Stats & Videos | Cricbuzz.com", title);
		 

	}

	@Then("^user click the schedule module$")
	public void user_click_the_schedule_module() 
	{

		schedulepageobj = homepageobj.clickSchedule();
		
	}
	@Then("^user click the series module$")
	public void user_click_the_series_module() 
	{

		seriespageobj = homepageobj.clickSeries();
		
	}
	
	@Then("^user clicks the livescore module$")
	public void user_clicks_the_livescore_module()
	{
	
		livescorepageobj= homepageobj.clickLiveScore();
		
	}

	@Then("^user close the browser$")
	public void user_close_the_browser() {

		driver.quit();
	}

}
