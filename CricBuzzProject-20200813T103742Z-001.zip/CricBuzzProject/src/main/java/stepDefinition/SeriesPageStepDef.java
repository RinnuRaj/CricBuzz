package stepDefinition;

import basement.CricBuzzBasement;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;
import pages.HomePage;
import pages.SeriesPage;

public class SeriesPageStepDef extends CricBuzzBasement
{

	HomePage homepageobj;
	SeriesPage seriespageobj;
	
	
	@Given("^client step into the cricbuzz webpage$")
	public void client_step_into_the_cricbuzz_webpage() throws Throwable 
	{
	
		startup();
		homepageobj = new HomePage();
		
	}

	@When("^client hit the series$")
	public void client_hit_the_series() throws Throwable 
	{
	
		seriespageobj = homepageobj.clickSeries();
	}

	@Then("^client validate the series page$")
	public void client_validate_the_series_page() throws Throwable 
	{
		//String seriestitle = driver.getTitle();
		//Assert.assertEquals("Australia Cricket Team live scores, fixtures - Cricbuzz", seriestitle);
	   System.out.println("Aussy");
	}

	@Then("^client fetch the series detail$")
	public void client_fetch_the_series_detail() throws Throwable 
	{
	
		seriespageobj.writeSeriesDetail();
		
	}

	@Then("^client exit from cricbuzz$")
	public void client_exit_from_cricbuzz() throws Throwable 
	{
	
		driver.quit();
		
	}


	
	
}
