package stepDefinition;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;

import basement.CricBuzzBasement;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;
import pages.HomePage;
import pages.SchedulePage;
import utilPack.CricBuzzUtil;

public class SchedulePageStepDef extends CricBuzzBasement
{

	HomePage homepageobj;
	SchedulePage schedulepageobj;	
	
	@Given("^customer enter the cricbuzz url in browser$")
	public void customer_enter_the_cricbuzz_url_in_browser()
	{
		startup();
		homepageobj = new HomePage();
	    
	}

	@When("^customer clicks schedule$")
	public void customer_clicks_schedule() throws InterruptedException
	{
	
		schedulepageobj = homepageobj.clickSchedule();
		
		
	}

	@Then("^customer validate the schedule page$")
	public void customer_validate_the_schedule_page()
	{
	
		String scheduletitle = driver.getTitle();
		Assert.assertEquals("Cricket Schedule - International, domestic and T20 matches - Cricbuzz | Cricbuzz.com", scheduletitle);
	}

	@Then("^customer write schedule detail$")
	public void customer_clicks_detail() throws Exception
	{
		//driver.manage().timeouts().pageLoadTimeout(70, TimeUnit.SECONDS);
		CricBuzzUtil.scrollMethod();
		schedulepageobj.writedata();
			
	}
	@Then("^customer close the cricbuzz site$")
	public void customer_close_the_cricbuzz_site()
	{
		driver.quit();
	}
}
