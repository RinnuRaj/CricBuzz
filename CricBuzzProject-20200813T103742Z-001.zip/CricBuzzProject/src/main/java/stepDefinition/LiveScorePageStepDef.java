package stepDefinition;

import basement.CricBuzzBasement;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;
import pages.HomePage;
import pages.LiveScorePage;
import pages.SeriesPage;

public class LiveScorePageStepDef extends CricBuzzBasement
{
	HomePage homepageobj;
	SeriesPage seriespageobj;
	LiveScorePage livescorepageobj;

	@Given("^stakeholder get into the cricbuzz page$")
	public void stakeholder_get_into_the_cricbuzz_page() 
	{
		startup();
		homepageobj = new HomePage();
	   
	}

	@When("^stakeholder press the livescore module$")
	public void stakeholder_press_the_livescore_module()
	{
		homepageobj.clickLiveScore();
		livescorepageobj = new LiveScorePage();
		
	 }

	@Then("^stakeholder validate the livescore page$")
	public void stakeholder_validate_the_livescore_page()
	{
		String livescorepagetitle = driver.getTitle();
		Assert.assertEquals("Cricket scorecard - ENG vs WI, 1st Test, West Indies tour of England, 2020 | Cricbuzz.com", livescorepagetitle);
	}

	@Then("^stakeholder take the scorecard details$")
	public void stakeholder_take_the_scorecard_details() throws Exception
	{
	
		livescorepageobj.writeScore();
		
	}
	
	@Then("^stakeholder leaves from cricbuzz$")
	public void stakeholder_leaves_from_cricbuzz()
	{
		driver.quit();
	}

}
