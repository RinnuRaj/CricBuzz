package pages;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import basement.CricBuzzBasement;
import utilPack.CricBuzzUtil;

public class LiveScorePage extends CricBuzzBasement 
{
	@FindBy(xpath = "//h1[@class='cb-nav-hdr cb-font-18 line-ht24']")
	WebElement title;

	@FindBy(xpath = "//div[@class='cb-col cb-scrcrd-status cb-col-100 cb-text-complete ng-scope']")
	WebElement result;
	
	@FindBy(xpath = "(//div[@class='cb-col cb-col-100 cb-scrd-hdr-rw'])")
	private List<WebElement> innings;
	
	@FindBy(xpath = "(//div[@class='cb-col cb-col-27 text-bold'])")
	private List<WebElement> batsmanheading;
	
	@FindBy(xpath = "(//div[@class='cb-col cb-col-8 text-right text-bold'])")
	private List<WebElement> batsmanruns;
	
	@FindBy(xpath = "(//div[@class='cb-col cb-col-8 text-right'])")
	private List<WebElement> ballsfoursr;
	
	@FindBy(xpath = "(//div[@class='cb-col cb-col-8	text-right'])")
	private List<WebElement> sixes;

	@FindBy(xpath = "(//div[@class='cb-col cb-col-27 '])")
	private List<WebElement> batsmannamelist;
	
	@FindBy(xpath = "(//div[@class='cb-col cb-col-33'])")
	private List<WebElement> typeofwicket;


	public LiveScorePage() 
	{
		PageFactory.initElements(driver, this);
	}

	public void writeScore() throws Exception
	{
		src = new File(CricBuzzUtil.WRITE_DATA_EXCELPATH);
		fis=  new FileInputStream(src); 
    	workbook = new XSSFWorkbook(fis);
    	sheet= workbook.createSheet("run4");
    	
    	row1 = sheet.createRow(0);
    	sheet.getRow(0).createCell(0).setCellValue(title.getText());
    	
    	
    	for(int i = 0; i<=0; i++)
    	{
    		String inningsdetail = innings.get(i).getText();
    		sheet.createRow(i+1).createCell(0).setCellValue(inningsdetail);
    		
    		for(int j = 0; j<=i; j++)
    		{
    			String batsmanheadingdetail = batsmanheading.get(j).getText();
    			sheet.createRow(j+2).createCell(0).setCellValue(batsmanheadingdetail);
    			
    			for(int k = 0; k<=i; k++)
    			{
    				String batsmanrundetails = batsmanruns.get(k).getText();
    				sheet.getRow(j+2).createCell(2).setCellValue(batsmanrundetails);
    				
    				for(int x = 0; x<=3; x++)
    				{
    					String ballfoursrdetail = ballsfoursr.get(x).getText();
    					sheet.getRow(j+2).createCell(3+x).setCellValue(ballfoursrdetail);
    					
    				}
    			}
    			
    			
    		}
    		
    	}
    	
		for(int y = 0; y<=10; y++)
		{
			String batsmannamelistdetail = batsmannamelist.get(y).getText();
			sheet.createRow(y+3).createCell(0).setCellValue(batsmannamelistdetail);
		}

		for(int k = 1; k<=11; k++)
		{
			String batsmanrundetails = batsmanruns.get(k).getText();
			sheet.getRow(k+2).createCell(2).setCellValue(batsmanrundetails);
		
		}
		
		int b=0;
		int a=3;
		for(int z=4; z<=9; z++)
		{
			String ballfoursr = ballsfoursr.get(z).getText();
			if(z==6)
			{
				sheet.getRow(a).createCell(6).setCellValue(ballfoursr);
				a++;
			}
			else if(z==9)
			{
				sheet.getRow(a).createCell(6).setCellValue(ballfoursr);
				a++;
			}
			else {
			
			sheet.getRow(a).createCell(3+b).setCellValue(ballfoursr);
			}
		
			
			b++;
		}
    	
		
    	fos=new FileOutputStream(src); 
		workbook.write(fos); 
		workbook.close();
    	
	}

}
