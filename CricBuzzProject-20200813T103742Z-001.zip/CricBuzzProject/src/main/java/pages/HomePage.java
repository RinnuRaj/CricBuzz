package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import basement.CricBuzzBasement;

public class HomePage extends CricBuzzBasement
{
	
	@FindBy(xpath = "//a[@title='Cricket Schedule']")
	WebElement schedule;
	
	@FindBy(xpath="(//a[@class='text-white'])[3]")
	WebElement team;
	
	
	@FindBy(xpath="//a[@class='cb-subnav-item cb-sub-lg-sec-item' and contains(text(), 'Australia')]")
	WebElement aussy;
	
	@FindBy(xpath = "(//a[@class='cb-hm-mnu-itm'])[1]")
	WebElement livescore;
	
	
	//@FindBy(xpath = "//a[contains(@class, 'cb-nav-tab cb-ranking-nav active')]")
	//WebElement live;
	
	@FindBy(xpath = "//div[@class='cb-font-16 cb-col-rt']")
	WebElement nomatches;
	
	@FindBy(xpath="(//a[contains(@class, 'cb-nav-tab cb-ranking-nav')])[2]")
	WebElement recent;
	
	
	
	@FindBy(xpath = "(//a[contains(@class, 'cb-text-link cb-mtch-lnks')])[2]")
	WebElement scorecard;
	
	
	public HomePage()
	{
		PageFactory.initElements(driver, this);
	}

	public SchedulePage clickSchedule()
	{
		schedule.click();
		
		return new SchedulePage();
		
	}
	
	public SeriesPage clickSeries()
	{
		Actions action = new Actions(driver);
		action.moveToElement(team).build().perform();
		aussy.click();
		
		return new SeriesPage();
	}
	
	public LiveScorePage clickLiveScore()
	{
		livescore.click();
		
		String status = nomatches.getText();
		
		if(status.contains("There are no matches at the moment. Please check back later."))
		{
			recent.click();
			scorecard.click();
		}
		
		return new LiveScorePage();
	}

}
