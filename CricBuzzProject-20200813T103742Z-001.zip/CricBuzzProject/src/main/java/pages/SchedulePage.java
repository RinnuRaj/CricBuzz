package pages;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import basement.CricBuzzBasement;
import utilPack.CricBuzzUtil;

public class SchedulePage extends CricBuzzBasement
{
	
	@FindBy(xpath = "//div[@class='cb-lv-grn-strip text-bold' and not(contains(text(), 'SAT'))]//parent::div[@class= 'cb-col-100 cb-col']")
	private List<WebElement> scheduledetail;
	
	public SchedulePage() 
	{
		PageFactory.initElements(driver, this);
	}

	public void writedata() throws Exception
	{
		src = new File(CricBuzzUtil.WRITE_DATA_EXCELPATH);
		fis=  new FileInputStream(src); 
    	workbook = new XSSFWorkbook(fis);
    	sheet= workbook.createSheet("Schedule4");
    	
//    	XSSFCellStyle style = workbook.createCellStyle();
//		XSSFFont font = workbook.createFont();
//		font.setBold(true);
//		style.setFont(font);
//    	
    	      	
    	for(int j = 0; j<scheduledetail.size(); j++)
		{
    			row1= sheet.createRow(j);
	    		
   				String alldetail = scheduledetail.get(j).getText();
   				
   				String datey = alldetail.substring(0, 16);
				String match = alldetail.substring(17);
   				
			sheet.getRow(j).createCell(0).setCellValue(datey);
			
			sheet.getRow(j).createCell(1).setCellValue(match);
		}
			
		  	
    	fos=new FileOutputStream(src); 
		workbook.write(fos); 
		workbook.close();
		
	}
}
