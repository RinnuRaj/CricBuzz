package pages;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import basement.CricBuzzBasement;
import utilPack.CricBuzzUtil;

public class SeriesPage extends CricBuzzBasement
{

	@FindBy(xpath="//a[@title='Australia Cricket Team Schedule']")
	WebElement schl;
	
	@FindBy(xpath = "//div[@class='cb-col-25 cb-col pad10 schedule-date  ng-isolate-scope']")
	private List<WebElement> date;
	
	@FindBy(xpath = "//div[@class='cb-col-60 cb-col cb-srs-mtchs-tm cb-ovr-flo']")
	private List<WebElement> matchdetail;
	
	@FindBy(xpath = "//div[@class='cb-col-40 cb-col cb-srs-mtchs-tm ']")
	private List<WebElement> time;

	
	public SeriesPage() 
	{
	
		PageFactory.initElements(driver, this);
	}
	
	
	public void writeSeriesDetail() throws Exception
	{
		
		schl.click();
		
		src = new File(CricBuzzUtil.WRITE_DATA_EXCELPATH);
		fis=  new FileInputStream(src); 
    	workbook = new XSSFWorkbook(fis);
    	sheet= workbook.createSheet("Series4");
    	
//    	XSSFCellStyle style = workbook.createCellStyle();
//		XSSFFont font = workbook.createFont();
//		font.setBold(true);
//		style.setFont(font);
//    	
		
		

		
    	      	
    	for(int j = 0; j<date.size(); j++)
		{
    		
    		row1=sheet.createRow(0);
    		sheet.getRow(0).createCell(0).setCellValue("Date");
    		
    		sheet.getRow(0).createCell(1).setCellValue("Match Details");
    		
    		sheet.getRow(0).createCell(2).setCellValue("Time");
    		
    		
    			row1= sheet.createRow(j+1);
	    		
   				String aussydate = date.get(j).getText();
   				String aussymatc = matchdetail.get(j).getText();
   				String aussytime = time.get(j).getText();

   				
   				sheet.getRow(j+1).createCell(0).setCellValue(aussydate);
   				sheet.getRow(j+1).createCell(1).setCellValue(aussymatc);
   				sheet.getRow(j+1).createCell(2).setCellValue(aussytime);
			
   		
		}
    			
		fos=new FileOutputStream(src); 
		workbook.write(fos); 
		workbook.close();
	}
	
}
