package utilPack;

import org.openqa.selenium.JavascriptExecutor;

import basement.CricBuzzBasement;

public class CricBuzzUtil extends CricBuzzBasement
{
	public static int IMPLICT_TIMEOUT = 60;
	public static int PAGELOAD_TIMEOUT = 60;
	public static String WRITE_DATA_EXCELPATH = "C:\\Users\\hp\\Desktop\\cricbuzz\\Result.xlsx";


	public static void scrollMethod() throws InterruptedException
	{
		JavascriptExecutor js = (JavascriptExecutor) driver;
		
		Thread.sleep(1000);
		//long lastHeight = ((Number) js.executeScript("return document.body.scrollHeight")).longValue();
		//while(true)
		
			for (int i = 0; i <= 18; i++)

					{
						js = (JavascriptExecutor) driver;
						Thread.sleep(500);
						js.executeScript("window.scrollBy(0,10000)");
						Thread.sleep(2000);
					}


		
//		{
//			js.executeScript("window.scrollBy(0, 1000)", "");
//			Thread.sleep(3000);
//			
//			long newHeight = ((Number) js.executeScript("return document.body.scrollHeight")).longValue();
//			
//			if(newHeight==lastHeight)
//			{
//				break;
//			}
//			lastHeight = newHeight;
//		}
	}
	
}
