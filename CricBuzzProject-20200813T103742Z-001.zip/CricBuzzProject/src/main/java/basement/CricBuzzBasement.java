package basement;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import utilPack.CricBuzzUtil;

public class CricBuzzBasement 
{

	public static WebDriver driver;
	public static Properties prop;
	public static File src;
	public static FileInputStream fis;
	public static XSSFWorkbook workbook;
	public static XSSFSheet sheet;
	public static FileOutputStream fos;
	public static XSSFRow row0;
	public static XSSFRow row1;
	
	public CricBuzzBasement()
	{
		try {
		prop = new Properties();
		fis = new FileInputStream("C:\\Users\\hp\\eclipse-workspace\\CricBuzzProject\\src\\main\\java\\config\\configcricbuzz.properties");
		prop.load(fis);
			}
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public void startup()
	{
		System.setProperty("webdriver.chrome.driver", "G:\\Selenium\\chromedriver-9-06-20\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().pageLoadTimeout(CricBuzzUtil.PAGELOAD_TIMEOUT, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(CricBuzzUtil.IMPLICT_TIMEOUT, TimeUnit.SECONDS);
		driver.get(prop.getProperty("url"));
		
		
	}
}
